DEFAULT_PROVIDERS = {
    "proxyapi": {
        "name": "ProxyAPI (работает в корпоративной сети)",
        "base_url": "https://openai.api.proxyapi.ru/v1",
        "hint": "Ключ: кабинет proxyapi.ru",
        "models": {"openai/gpt-4o-mini": "GPT-4o Mini", "openai/gpt-4o": "GPT-4o", "anthropic/claude-3.5-sonnet": "Claude 3.5 Sonnet", "gemini/gpt-4o-mini": "Gemini 2.0 Flash"}
    },
    "gigachat": {
        "name": "GigaChat (Сбербанк)",
        "base_url": "https://api.giga.chat/v1",
        "hint": "Ключ авторизации из кабинета developers.sber.ru (физлица) - токен библиотека получает сама",
        "models": {"GigaChat": "GigaChat (базовая)", "GigaChat-2": "GigaChat-2", "GigaChat-2-Max": "GigaChat-2 Max", "GigaChat-2-Pro": "GigaChat-2 Pro"}
    },
    "groq": {
        "name": "Groq (бесплатно, быстро)",
        "base_url": "https://api.groq.com/openai/v1",
        "hint": "Ключ: console.groq.com/keys",
        "models": {"llama-3.3-70b-versatile": "Llama 3.3 70B", "llama-3.1-8b-instant": "Llama 3.1 8B", "gemma2-9b-it": "Gemma 2 9B", "mixtral-8x7b-32768": "Mixtral 8x7B"}
    },
    "openrouter": {
        "name": "OpenRouter (free-модели)",
        "base_url": "https://openrouter.ai/api/v1",
        "hint": "Ключ: openrouter.ai/keys",
        "models": {"meta-llama/llama-3.3-70b-instruct:free": "Llama 3.3 70B (free)", "google/gemma-2-9b-it:free": "Gemma 2 9B (free)", "qwen/qwen-2.5-coder-32b-instruct:free": "Qwen 2.5 Coder (free)"}
    },
    "mistral": {
        "name": "Mistral AI (тариф Experiment)",
        "base_url": "https://api.mistral.ai/v1",
        "hint": "Ключ: console.mistral.ai",
        "models": {"open-mistral-7b": "Mistral 7B", "open-mixtral-8x7b": "Mixtral 8x7B", "mistral-small-latest": "Mistral Small"}
    },
    "cohere": {
        "name": "Cohere (trial)",
        "base_url": "https://api.cohere.com/compatibility/v1",
        "hint": "Ключ: dashboard.cohere.com",
        "models": {"command-r": "Command R", "command-r-plus": "Command R+"}
    },
    "hyperbolic": {
        "name": "Hyperbolic (кредиты)",
        "base_url": "https://api.hyperbolic.ai/v1",
        "hint": "Ключ: app.hyperbolic.ai",
        "models": {"meta-llama/llama-3.3-70b-instruct": "Llama 3.3 70B", "meta-llama/llama-3.1-8b-instruct": "Llama 3.1 8B"}
    },
    "nlpcloud": {
        "name": "NLP Cloud (trial)",
        "base_url": "https://api.nlpcloud.io/v1",
        "hint": "Ключ: nlpcloud.com",
        "models": {"dolphin": "Dolphin", "finetuned-gpt-neox-20b": "GPT-NeoX 20B"}
    },
    "google": {
        "name": "Google AI Studio (Gemini free)",
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
        "hint": "Ключ: aistudio.google.com/apikey",
        "models": {"gemini-1.5-flash": "Gemini 1.5 Flash", "gemini-2.0-flash": "Gemini 2.0 Flash"}
    },
    "github": {
        "name": "GitHub Models (бесплатно)",
        "base_url": "https://models.inference.ai.azure.com",
        "hint": "Ключ: токен GitHub",
        "models": {"gpt-4o-mini": "GPT-4o Mini", "meta-llama-3.1-8b-instant": "Llama 3.1 8B"}
    }
}

EMBEDDING_MODELS = [
    "paraphrase-multilingual-MiniLM-L12-v2 (локально, по умолчанию)",
    "BAAI/bge-small-en-v1.5 (локально, английский)"
]
