from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
from jose import jwt
from sqlalchemy import text as _text
from app.database import engine, Base, SessionLocal
from app.config import settings
from app.routers import auth, forum, chat, ai, admin, ai_settings, users_admin

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Support Forum with RAG", version="1.0.0")

class BanMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        public = path.startswith("/auth/") or path in ("/", "/docs", "/openapi.json")
        if not public:
            header = request.headers.get("authorization", "")
            uid = None
            if header.startswith("Bearer "):
                try:
                    payload = jwt.decode(header[7:], settings.SECRET_KEY, algorithms=[getattr(settings, "ALGORITHM", "HS256")])
                    uid = payload.get("sub") or payload.get("user_id") or payload.get("id")
                except Exception:
                    uid = None
            if uid:
                db = SessionLocal()
                try:
                    row = db.execute(_text("SELECT is_banned FROM users WHERE CAST(id AS TEXT)=:id"), {"id": str(uid)}).fetchone()
                finally:
                    db.close()
                if row is not None and row[0]:
                    return JSONResponse(status_code=403, content={"detail": "Вы забанены администратором"})
        return await call_next(request)

app.add_middleware(BanMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(forum.router, prefix="/forum", tags=["forum"])
app.include_router(chat.router, prefix="/chat", tags=["chat"])
app.include_router(ai.router, prefix="/ai", tags=["ai"])
app.include_router(admin.router, prefix="/admin", tags=["admin"])
app.include_router(ai_settings.router, prefix="/ai-settings", tags=["ai-settings"])
app.include_router(users_admin.router, prefix="/admin", tags=["users"])

@app.get("/")
def root():
    return {"message": "Support Forum API is running"}
