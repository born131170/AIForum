import os, re, math, hashlib, json, shutil, sqlite3
from typing import Dict, List
from dotenv import load_dotenv
load_dotenv(override=True)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain_chroma import Chroma

CHROMA="./chroma_db"; SIGP="./chroma_sig.txt"

def _full_cfg():
    p=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ai_config.json")
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return {}

def _emb_cfg():
    return _full_cfg().get("embedding") or {"kind":"local","model":"auto","provider":""}

class ConfigurableEmbedder:
    def __init__(self, ecfg):
        self.ecfg=ecfg; self._ready=False; self.mode="hash"; self.m=None
    def _ensure(self):
        if self._ready: return
        self._ready=True
        kind=self.ecfg.get("kind","local")
        if kind=="gigachat":
            self.mode="gigachat"; print("[rag] emb: GigaChat API |", self.ecfg.get("model"))
        elif kind=="openai":
            self.mode="openai"; print("[rag] emb: OpenAI API |", self.ecfg.get("model"), "| провайдер:", self.ecfg.get("provider"))
        else:
            try:
                from fastembed import TextEmbedding
                want=self.ecfg.get("model","auto")
                cands=[] if want in ("auto","") else [want]
                cands+=["sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2","paraphrase-multilingual-MiniLM-L12-v2"]
                try:
                    for m in TextEmbedding.list_supported_models():
                        n=m.get("model","")
                        if "multilingual" in n.lower() and n not in cands:
                            cands.append(n)
                except Exception:
                    pass
                cands.append("BAAI/bge-small-en-v1.5")
                for c in cands:
                    try:
                        self.m=TextEmbedding(model_name=c); _=list(self.m.embed(["init"]))
                        self.mode="fastembed"; print("[rag] emb: fastembed |", c); break
                    except Exception as ex:
                        print("[rag] модель", c, "недоступна:", repr(ex)[:60])
            except Exception as ex:
                self.mode="hash"; print("[rag] emb: hash", repr(ex)[:120])
    @staticmethod
    def _norm(v):
        n=math.sqrt(sum(x*x for x in v)) or 1.0
        return [x/n for x in v]
    def _hash(self, text):
        v=[0.0]*384
        clean="".join(c if c.isalnum() or c.isspace() else " " for c in text.lower())
        for tok in clean.split():
            v[int(hashlib.md5(tok.encode("utf-8")).hexdigest(),16)%384]+=1.0
        return self._norm(v)
    def _api_embed(self, texts):
        cfg=_full_cfg(); out=[]
        if self.mode=="gigachat":
            from gigachat import GigaChat
            key=cfg.get("providers",{}).get("gigachat",{}).get("api_key","")
            g=GigaChat(base_url="https://api.giga.chat/v1", credentials=key, verify_ssl_certs=False)
            mdl=self.ecfg.get("model") or "Embeddings-2"
            for i in range(0, len(texts), 16):
                batch=texts[i:i+16]
                try:
                    r=g.embeddings(batch, model=mdl)
                except TypeError:
                    r=g.embeddings(input=batch, model=mdl)
                out+=[d.embedding for d in r.data]
        else:
            from openai import OpenAI
            pid=self.ecfg.get("provider") or ("proxyapi" if "proxyapi" in cfg.get("providers",{}) else cfg.get("active_provider","proxyapi"))
            meta=cfg.get("providers",{}).get(pid,{})
            c=OpenAI(api_key=meta.get("api_key",""), base_url=meta.get("base_url","https://openai.api.proxyapi.ru/v1"), timeout=120)
            mdl=self.ecfg.get("model") or "text-embedding-3-small"
            import time as _t
            for i in range(0, len(texts), 16):
                batch=texts[i:i+16]
                for att in range(4):
                    try:
                        r=c.embeddings.create(model=mdl, input=batch)
                        out+=[d.embedding for d in r.data]
                        break
                    except Exception as ex:
                        print("[rag] ошибка пакета эмбеддинга (попытка", att+1, "из 4):", repr(ex)[:100])
                        if att==3:
                            raise
                        _t.sleep(2+att*3)
                print("[rag] эмбеддинг:", min(i+16, len(texts)), "/", len(texts))
        return out
    def _local_fallback(self):
        if self.m is None:
            from fastembed import TextEmbedding
            for c in ["sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2", "paraphrase-multilingual-MiniLM-L12-v2", "BAAI/bge-small-en-v1.5"]:
                try:
                    self.m = TextEmbedding(model_name=c)
                    print("[rag] fallback: локальный эмбеддинг", c)
                    break
                except Exception:
                    pass
    def embed_documents(self, texts):
        self._ensure()
        if self.mode in ("gigachat","openai"):
            try:
                return [self._norm(v) for v in self._api_embed(texts)]
            except Exception as ex:
                print("[rag] API эмбеддингов недоступен:", repr(ex)[:120], "- переход на локальный")
                self._local_fallback()
                self.mode = "fastembed" if self.m is not None else "hash"
                return [self._norm(e.tolist()) for e in self.m.embed(texts)] if self.m is not None else [self._hash(t) for t in texts]
        if self.mode=="fastembed":
            return [self._norm(e.tolist()) for e in self.m.embed(texts)]
        return [self._hash(t) for t in texts]
    def embed_query(self, text):
        self._ensure()
        if self.mode in ("gigachat","openai"):
            try:
                return self._norm(self._api_embed([text])[0])
            except Exception as ex:
                print("[rag] API эмбеддингов недоступен:", repr(ex)[:120], "- переход на локальный")
                self._local_fallback()
                self.mode = "fastembed" if self.m is not None else "hash"
                return self._norm(list(self.m.embed([text]))[0].tolist()) if self.m is not None else self._hash(text)
        if self.mode=="fastembed":
            return self._norm(list(self.m.embed([text]))[0].tolist())
        return self._hash(text)

def _bootstrap():
    sig=json.dumps(_emb_cfg(), sort_keys=True)
    old=""
    if os.path.exists(SIGP):
        old=open(SIGP, encoding="utf-8").read().strip()
    if old!=sig and os.path.isdir(CHROMA):
        shutil.rmtree(CHROMA, ignore_errors=True)
        print("[rag] конфигурация эмбеддингов изменилась - база будет переиндексирована")
    os.makedirs(CHROMA, exist_ok=True)
    open(SIGP,"w",encoding="utf-8").write(sig)

_bootstrap()
emb=ConfigurableEmbedder(_emb_cfg())
vs=Chroma(collection_name="docs", embedding_function=emb, persist_directory=CHROMA, collection_metadata={"hnsw:space":"cosine"})
LM={"pdf":PyPDFLoader,"txt":TextLoader,"docx":Docx2txtLoader,"md":TextLoader}

def _load(path):
    ext=path.rsplit(".",1)[-1].lower()
    cls=LM.get(ext, TextLoader)
    if cls is TextLoader:
        for enc in ("utf-8","cp1251"):
            try:
                return TextLoader(path, encoding=enc).load()
            except UnicodeDecodeError:
                continue
        return TextLoader(path, encoding="utf-8", errors="ignore").load()
    if ext=="pdf":
        docs=[]
        try:
            docs=PyPDFLoader(path).load()
        except Exception as ex:
            print("[rag] ошибка PyPDFLoader:", repr(ex)[:100])
        if len("".join(d.page_content for d in docs).strip())<50:
            try:
                import fitz
                d2=fitz.open(path)
                text="\n".join((p.get_text() or "") for p in d2)
                if len(text.strip())>=50:
                    from langchain_core.documents import Document
                    docs=[Document(page_content=text)]
                    print("[rag] PDF прочитан через PyMuPDF")
            except Exception as ex:
                print("[rag] PyMuPDF недоступен:", repr(ex)[:80])
        return docs
    return cls(path).load()

def ingest_document(path, doc_id, filename):
    docs=_load(path)
    for d in docs: d.metadata.update({"filename":filename,"doc_id":doc_id})
    chunks=RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150).split_documents(docs)
    print("[rag] индексирую", filename, "->", len(chunks), "фрагментов")
    if not chunks:
        print("[rag] ВНИМАНИЕ: текст не извлечён (файл-скан?):", filename)
        return 0
    vs.add_documents(chunks); return len(chunks)

def reindex_all():
    dbp=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "support.db")
    conn=sqlite3.connect(dbp)
    rows=conn.execute("SELECT id, filename, path FROM documents").fetchall()
    conn.close()
    total=0
    for did, fname, path in rows:
        if os.path.exists(path):
            total+=ingest_document(path, str(did), fname)
    return total

try:
    if vs._collection.count()==0:
        print("[rag] база пуста - авто-переиндексация...")
        print("[rag] переиндексировано фрагментов:", reindex_all())
except Exception as ex:
    print("[rag] ошибка авто-переиндексации:", repr(ex)[:200])

def _ai_cfg():
    cfg=_full_cfg()
    provs=cfg.get("providers", {})
    ap=cfg.get("active_provider", "proxyapi")
    meta=provs.get(ap, {})
    return {"provider": ap,
            "key": meta.get("api_key", "") or os.getenv("API_KEY", ""),
            "base": meta.get("base_url", "") or "https://openai.api.proxyapi.ru/v1",
            "model": cfg.get("active_model", "") or "openai/gpt-4o-mini"}

def _gigachat(key, model, prompt_text, base=""):
    try:
        from gigachat import GigaChat
    except Exception:
        raise RuntimeError("библиотека gigachat не установлена в venv: выполните pip install gigachat")
    b = base or "https://api.giga.chat/v1"
    mdl = model or "GigaChat-3-Ultra"
    if "embed" in mdl.lower():
        mdl = "GigaChat-3-Ultra"
    os.environ["GIGACHAT_MODEL"] = mdl
    g = GigaChat(base_url=b, credentials=key, verify_ssl_certs=False)
    r = g.chat(prompt_text)
    return r.choices[0].message.content

def _gigachat_raw(key, model, prompt_text):
    import requests, base64
    try:
        import urllib3
        urllib3.disable_warnings()
    except Exception:
        pass
    auth = base64.b64encode(key.encode()).decode()
    tok = None
    for scope in ("GIGACHAT_API_PERSONAL", "GIGACHAT_API_CORP"):
        r = requests.post("https://gigachat.devices.sberbank.ru/api/v2/oauth",
                          headers={"Authorization": "Basic " + auth, "Accept": "application/json"},
                          data={"scope": scope}, timeout=30, verify=False)
        if r.ok:
            tok = r.json().get("access_token", "")
            break
    if not tok:
        raise RuntimeError("GigaChat OAuth: не удалось получить токен")
    r2 = requests.post("https://gigachat.devices.sberbank.ru/api/v1/chat/completions",
                       headers={"Authorization": "Bearer " + tok},
                       json={"model": model, "messages": [{"role": "user", "content": prompt_text}]},
                       timeout=120, verify=False)
    r2.raise_for_status()
    return r2.json()["choices"][0]["message"]["content"]

def _complete(cfg, prompt_text):
    prov=cfg.get("provider", "proxyapi"); key=cfg.get("key", ""); base=cfg.get("base", ""); model=cfg.get("model", "openai/gpt-4o-mini")
    if prov=="nlpcloud":
        import requests
        r=requests.post(base+"/"+model+"/chatbot", headers={"Authorization":"Token "+key}, json={"text":prompt_text}, timeout=120)
        r.raise_for_status()
        return r.json().get("response","")
    if prov=="gigachat":
        return _gigachat(key, model, prompt_text, base)
    headers=None
    if prov=="openrouter" or "openrouter" in base:
        headers={"HTTP-Referer":"http://localhost:5173","X-Title":"Support Forum"}
    from openai import OpenAI
    c=OpenAI(api_key=key, base_url=base, default_headers=headers, timeout=120)
    r=c.chat.completions.create(model=model, temperature=0, messages=[{"role":"user","content":prompt_text}])
    if not r.choices:
        return "(модель вернула пустой ответ)"
    return r.choices[0].message.content or "(пустой ответ)"

PROMPT=("Ты ассистент техподдержки по документации. Отвечай на вопрос СТРОГО по контексту ниже. "
        "Используй даже частичные упоминания из контекста. "
        "Говори, что в документации не нашлось, ТОЛЬКО если в контексте действительно ничего по теме нет. Перед ответом 'не нашлось' ОБЯЗАННО перечитай весь контекст ещё раз: сведения могут быть в таблицах, рисунках и соседних фрагментах. "
        "Если спрашивают, кто ты или какая ты модель - отвечай: 'Я ассистент поиска по документации; конкретную модель выбирает администратор в админ-панели.' Не выдумывай названия моделей. "
        "Таблицы в контексте могут выглядеть как наборы чисел и обозначений типоразмеров (G16, G100, Dy, Dk, A, B и т.п.) - если вопрос о размерах, габаритах или массе, ищи такие строки в контексте и приводи найденные числа.\n\n"
        "Контекст:\n{context}\n\nВопрос: {question}\n\nОтвет:")

def query_rag(question, top_k=10):
    load_dotenv(override=True)
    cfg=_ai_cfg()
    print("[rag] старт поиска...")
    space="l2"
    try:
        space=(getattr(vs._collection, "metadata", {}) or {}).get("hnsw:space", "l2")
    except Exception:
        pass
    thr=0.6 if space=="cosine" else 1.0
    m=re.search(r"ЛГТИ\.\d+\.\d+\S*", question)
    code=m.group(0).rstrip(".,;:!?") if m else None
    if not code:
        for tok in ("РГ-Т","РГ-К","РГ-Р","RVG","RABO","ВК"):
            if tok.lower() in question.lower():
                code=tok; break
    scored=[]
    if code:
        dbp=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "support.db")
        names=[r[0] for r in sqlite3.connect(dbp).execute("SELECT filename FROM documents WHERE filename LIKE ?", ("%" + code + "%",)).fetchall()]
        print("[rag] совпавшие файлы:", names)
        flt={"filename": {"$in": names}} if names else {"filename": {"$contains": code}}
        print("[rag] фильтр по документу:", code)
        for attempt in (lambda: vs.similarity_search_with_score(question, k=top_k, filter=flt),
                        lambda: vs.similarity_search_with_score(question, k=top_k, where=flt),
                        lambda: vs.similarity_search_with_score(question, k=top_k)):
            try:
                scored=attempt()
                print("[rag] результатов:", len(scored))
                if scored:
                    break
            except Exception as ex:
                print("[rag] вариант поиска не сработал:", repr(ex)[:80])
    else:
        try:
            scored=vs.similarity_search_with_score(question, k=top_k)
        except Exception:
            scored=[]
    stop={"что","какое","какой","какая","какие","где","когда","говорится","сказано","применяется","про","о","об","в","во","документ","документе","этот","этом","из","по","на","и","ли","чем","сколько","тебе","известно","счетчике","каков"}
    code_l=code.lower() if code else ""
    kws=[w for w in re.findall(r"[а-яёa-z]{4,}", question.lower()) if w not in stop and w not in code_l]
    if kws:
        kw=max(kws, key=len)
        stem=kw[:4] if len(kw)>4 else kw
        try:
            from langchain_core.documents import Document as _Doc
            wfl={"filename": {"$in": names}} if (code and names) else None
            try:
                hit=vs.similarity_search_with_score(kw, k=8, filter=wfl) if wfl else vs.similarity_search_with_score(kw, k=8)
            except TypeError:
                hit=vs.similarity_search_with_score(kw, k=8)
            seen=set()
            for d,_s in scored:
                seen.add((d.page_content or "")[:80])
            added=0
            for d,_sc in hit:
                txt=d.page_content or ""
                if stem in txt.lower() and txt[:80] not in seen:
                    seen.add(txt[:80])
                    scored.insert(0, (d, 0.05))
                    kw_hits.append("[" + str(d.metadata.get("filename")) + "] " + txt)
                    added+=1
            print("[rag] шапка контекста:", [h[:70] for h in kw_hits[:4]])
            print("[rag] ключевое слово '"+kw+"' (основа '"+stem+"') добавило кусков:", added)
        except Exception as ex:
            print("[rag] ключевой поиск не сработал:", repr(ex)[:100])
    ded=[]; seen=set()
    for d,sc in scored:
        key=(d.page_content or "")[:80]
        if key in seen:
            continue
        seen.add(key); ded.append((d,sc))
    scored=ded
    docs=[]; sources=[]
    for d, sc in scored:
        try:
            dist=float(sc)
        except Exception:
            dist=0.0
        print("[rag] score:", round(dist,3), "|", (d.page_content or "")[:80].replace("\n"," "))
        if dist<=thr:
            docs.append(d)
            sources.append({"file": d.metadata.get("filename","?"), "snippet": (d.page_content or "")[:300]})
    docs=docs[:12]; sources=sources[:12]
    if docs:
        context="\n---\n".join("[" + str(d.metadata.get("filename")) + "]" + d.page_content for d in docs)
    else:
        context="(пусто - в документации ничего по этой теме)"
    print("[rag] вызов LLM...")
    try:
        pt=cfg.get("prompt") or ""
        if "{context}" not in pt or "{question}" not in pt:
            pt=PROMPT
        answer=_complete(cfg, pt.replace("{context}", context).replace("{question}", question))
        print("[rag] LLM ответил")
    except Exception as ex:
        answer="Ошибка провайдера AI: " + repr(ex)[:200]
    return {"answer": answer, "sources": sources}
