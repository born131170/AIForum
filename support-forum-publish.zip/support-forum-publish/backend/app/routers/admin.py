import os, uuid, shutil
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import Document
from app.schemas import DocumentResponse
from app.auth import require_admin
from app.rag import ingest_document

router = APIRouter()
UPLOAD_DIR = "./uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.post("/upload", response_model=DocumentResponse)
async def upload_document(file: UploadFile = File(...), db: Session = Depends(get_db), current_user=Depends(require_admin)):
    allowed = {".pdf", ".txt", ".docx", ".md"}
    if os.path.splitext(file.filename)[1].lower() not in allowed:
        raise HTTPException(status_code=400, detail="Allowed: .pdf, .txt, .docx, .md")
    doc_id = str(uuid.uuid4())
    file_path = os.path.join(UPLOAD_DIR, f"{doc_id}_{file.filename}")
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    try:
        chunk_count = ingest_document(file_path, doc_id, file.filename)
    except Exception as e:
        os.remove(file_path)
        raise HTTPException(status_code=500, detail=str(e))
    doc = Document(id=doc_id, filename=file.filename, path=file_path, chunk_count=chunk_count, uploaded_by=current_user.id)
    db.add(doc)
    db.commit()
    db.refresh(doc)
    return doc

@router.get("/documents", response_model=List[DocumentResponse])
def list_documents(db: Session = Depends(get_db), current_user=Depends(require_admin)):
    return db.query(Document).order_by(Document.created_at.desc()).all()

@router.delete("/documents/{doc_id}")
def delete_document(doc_id: str, db: Session = Depends(get_db), current_user=Depends(require_admin)):
    doc = db.query(Document).filter(Document.id == doc_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    if os.path.exists(doc.path):
        os.remove(doc.path)
    db.delete(doc)
    db.commit()
    return {"message": "Document deleted"}
