from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Thread, Message, SenderType
from app.schemas import AskRequest, AskResponse
from app.auth import get_current_user
from app.rag import query_rag

router = APIRouter()

@router.post("/ask", response_model=AskResponse)
def ask_ai(payload: AskRequest, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    print("[ai] запрос получен:", (payload.question or "")[:80])
    result = query_rag(payload.question)
    if payload.thread_id:
        thread = db.query(Thread).filter(Thread.id == str(payload.thread_id)).first()
        if not thread:
            raise HTTPException(status_code=404, detail="Thread not found")
        db.add(Message(thread_id=str(payload.thread_id), sender_type=SenderType.user, content=payload.question, author_email=current_user.email))
        db.add(Message(thread_id=str(payload.thread_id), sender_type=SenderType.ai, content=result["answer"], sources=result["sources"]))
        db.commit()
    return result
