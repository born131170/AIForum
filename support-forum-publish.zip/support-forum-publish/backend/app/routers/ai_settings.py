import os, json
from typing import Dict
from dotenv import load_dotenv
load_dotenv(override=True)
import requests
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.auth import require_admin
from app.ai_providers import DEFAULT_PROVIDERS, EMBEDDING_MODELS

router = APIRouter()
CFG_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "ai_config.json")

def _load():
    if os.path.exists(CFG_PATH):
        try:
            return json.load(open(CFG_PATH, encoding="utf-8"))
        except Exception:
            pass
    return {}

def _save(cfg):
    json.dump(cfg, open(CFG_PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

def _ensure(cfg):
    if not cfg.get("providers"):
        provs = {}
        for pid, meta in DEFAULT_PROVIDERS.items():
            provs[pid] = {"name": meta["name"], "base_url": meta["base_url"], "hint": meta.get("hint", ""),
                          "api_key": "", "models": dict(meta["models"]), "custom": False}
        legacy_key = cfg.get("api_key") or os.getenv("API_KEY", "")
        legacy_prov = cfg.get("provider", "proxyapi")
        if legacy_prov in provs and legacy_key:
            provs[legacy_prov]["api_key"] = legacy_key
        cfg["providers"] = provs
        cfg.setdefault("active_provider", legacy_prov if legacy_prov in provs else "proxyapi")
        cfg.setdefault("active_model", cfg.get("model") or "openai/gpt-4o-mini")
        cfg.setdefault("embedding_model", EMBEDDING_MODELS[0])
    provs = cfg.get("providers") or {}
    for pid, meta in DEFAULT_PROVIDERS.items():
        if pid not in provs:
            provs[pid] = {"name": meta["name"], "base_url": meta["base_url"], "hint": meta.get("hint", ""),
                          "api_key": "", "models": dict(meta["models"]), "custom": False}
    cfg["providers"] = provs
    return cfg

def _mask(key):
    if not key:
        return None
    if len(key) > 12:
        return {"length": len(key), "preview": key[:6] + "..." + key[-4:]}
    return {"length": len(key), "preview": key[:2] + "..."}

class ActiveIn(BaseModel):
    provider: str
    model: str

class KeyIn(BaseModel):
    provider: str
    api_key: str

class ProviderIn(BaseModel):
    id: str
    name: str
    base_url: str
    api_key: str = ""
    models: Dict[str, str] = {}

class PromptIn(BaseModel):
    prompt: str = ""

@router.get("/state")
def get_state(current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    out = {}
    for pid, p in cfg["providers"].items():
        out[pid] = {"name": p.get("name", pid), "base_url": p.get("base_url", ""), "hint": p.get("hint", ""),
                    "custom": p.get("custom", False), "models": p.get("models", {}), "key": _mask(p.get("api_key", ""))}
    return {"providers": out, "active_provider": cfg.get("active_provider", "proxyapi"),
            "active_model": cfg.get("active_model", ""), "embedding_model": cfg.get("embedding_model", EMBEDDING_MODELS[0]),
            "prompt": cfg.get("prompt", "")}

@router.get("/models")
def live_models(provider: str, current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    p = cfg["providers"].get(provider)
    if not p:
        raise HTTPException(status_code=404, detail="Provider not found")
    try:
        r = requests.get(p["base_url"] + "/models", headers={"Authorization": "Bearer " + p.get("api_key", "")}, timeout=6)
        r.raise_for_status()
        ids = sorted(m.get("id", "") for m in r.json().get("data", []) if m.get("id"))
        if ids:
            return {"source": "live", "models": {i: i for i in ids}}
    except Exception:
        pass
    return {"source": "stored", "models": p.get("models", {})}

@router.post("/active")
def set_active(data: ActiveIn, current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    if data.provider not in cfg["providers"]:
        raise HTTPException(status_code=400, detail="Unknown provider")
    cfg["active_provider"] = data.provider
    cfg["active_model"] = data.model
    _save(cfg)
    return {"status": "ok", "message": "Сохранено! Применяется сразу."}

@router.post("/key")
def set_key(data: KeyIn, current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    p = cfg["providers"].get(data.provider)
    if not p:
        raise HTTPException(status_code=400, detail="Unknown provider")
    p["api_key"] = data.api_key.strip()
    _save(cfg)
    return {"status": "ok", "message": "Ключ сохранён для: " + p["name"]}

@router.post("/provider")
def add_provider(data: ProviderIn, current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    pid = data.id.strip().lower().replace(" ", "_") or data.name.strip().lower().replace(" ", "_")
    old_key = cfg["providers"].get(pid, {}).get("api_key", "")
    old_hint = cfg["providers"].get(pid, {}).get("hint", "Свой провайдер")
    cfg["providers"][pid] = {"name": data.name, "base_url": data.base_url.rstrip("/"), "hint": old_hint,
                             "api_key": data.api_key.strip() or old_key, "models": data.models or dict(cfg["providers"].get(pid, {}).get("models", {})) or {"default": "default"}, "custom": True}
    _save(cfg)
    return {"status": "ok", "message": "Провайдер добавлен: " + data.name}

@router.delete("/provider/{pid}")
def del_provider(pid: str, current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    if pid not in cfg["providers"]:
        raise HTTPException(status_code=404, detail="Not found")
    if cfg.get("active_provider") == pid:
        raise HTTPException(status_code=400, detail="Нельзя удалить активный провайдер")
    del cfg["providers"][pid]
    _save(cfg)
    return {"status": "ok", "message": "Провайдер удалён"}

@router.post("/prompt")
def save_prompt(data: PromptIn, current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    cfg["prompt"] = data.prompt.strip()
    _save(cfg)
    return {"status": "ok", "message": "Промпт сохранён. Применяется сразу."}

class EmbeddingIn(BaseModel):
    kind: str
    model: str
    provider: str = ""

@router.get("/embedding")
def get_embedding(current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    cur = cfg.get("embedding") or {"kind": "local", "model": "auto", "provider": ""}
    local_models = ["auto", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2", "BAAI/bge-small-en-v1.5"]
    try:
        from fastembed import TextEmbedding
        for m in TextEmbedding.list_supported_models():
            n = m.get("model", "")
            if "multilingual" in n.lower() and n not in local_models:
                local_models.append(n)
    except Exception:
        pass
    giga = ["Embeddings-2", "GigaEmbeddings-3B-2025-09", "Embeddings", "EmbeddingsGigaR"]
    try:
        from gigachat import GigaChat
        gk = cfg["providers"].get("gigachat", {}).get("api_key", "")
        if gk:
            gg = GigaChat(base_url="https://api.giga.chat/v1", credentials=gk, verify_ssl_certs=False)
            resp = gg.get_models()
            ids = [getattr(m, "id_", None) or getattr(m, "id", None) for m in (getattr(resp, "data", None) or [])]
            ids = [i for i in ids if i and "embed" in i.lower()]
            if ids:
                giga = ids
    except Exception:
        pass
    return {"current": cur, "local_models": local_models, "gigachat_models": giga,
            "openai_models": ["text-embedding-3-small", "text-embedding-3-large", "openai/text-embedding-3-small", "openai/text-embedding-3-large"],
            "providers": [{"id": pid, "name": p.get("name", pid)} for pid, p in cfg["providers"].items()]}

@router.post("/embedding")
def set_embedding(data: EmbeddingIn, current_user=Depends(require_admin)):
    cfg = _ensure(_load())
    prov = data.provider
    if data.kind == "openai" and not prov:
        prov = "proxyapi" if "proxyapi" in cfg["providers"] else cfg.get("active_provider", "proxyapi")
    cfg["embedding"] = {"kind": data.kind, "model": data.model, "provider": prov}
    _save(cfg)
    return {"status": "ok", "message": "Сохранено! Перезапустите uvicorn - база переиндексируется автоматически."}
