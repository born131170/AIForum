from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import Thread, Message, SenderType
from app.schemas import MessageCreate, MessageResponse
from app.auth import get_current_user

router = APIRouter()

@router.get("/threads/{thread_id}/messages", response_model=List[MessageResponse])
def get_messages(thread_id: str, db: Session = Depends(get_db), _=Depends(get_current_user)):
    thread = db.query(Thread).filter(Thread.id == thread_id).first()
    if not thread:
        raise HTTPException(status_code=404, detail="Thread not found")
    return db.query(Message).filter(Message.thread_id == thread_id).order_by(Message.created_at).all()

@router.post("/threads/{thread_id}/messages", response_model=MessageResponse)
def post_message(thread_id: str, message_data: MessageCreate, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    thread = db.query(Thread).filter(Thread.id == thread_id).first()
    if not thread:
        raise HTTPException(status_code=404, detail="Thread not found")
    msg = Message(thread_id=thread_id, sender_type=SenderType.user, content=message_data.content, author_email=current_user.email)
    db.add(msg)
    db.commit()
    db.refresh(msg)
    return msg
