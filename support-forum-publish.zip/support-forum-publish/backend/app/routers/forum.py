from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from app.database import get_db
from app.models import Topic, Thread
from app.schemas import TopicCreate, TopicResponse, ThreadCreate, ThreadResponse
from app.auth import get_current_user, require_admin

router = APIRouter()

@router.get("/topics", response_model=List[TopicResponse])
def list_topics(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(Topic).order_by(Topic.created_at.desc()).all()

@router.post("/topics", response_model=TopicResponse)
def create_topic(topic_data: TopicCreate, db: Session = Depends(get_db), current_user=Depends(require_admin)):
    topic = Topic(title=topic_data.title, description=topic_data.description, created_by=current_user.id)
    db.add(topic)
    db.commit()
    db.refresh(topic)
    return topic

@router.delete("/topics/{topic_id}")
def delete_topic(topic_id: str, db: Session = Depends(get_db), current_user=Depends(require_admin)):
    topic = db.query(Topic).filter(Topic.id == topic_id).first()
    if not topic:
        raise HTTPException(status_code=404, detail="Topic not found")
    db.delete(topic)
    db.commit()
    return {"message": "Topic deleted"}

@router.get("/topics/{topic_id}/threads", response_model=List[ThreadResponse])
def list_threads(topic_id: str, db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(Thread).filter(Thread.topic_id == topic_id).order_by(Thread.created_at.desc()).all()

@router.post("/topics/{topic_id}/threads", response_model=ThreadResponse)
def create_thread(topic_id: str, thread_data: ThreadCreate, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    topic = db.query(Topic).filter(Topic.id == topic_id).first()
    if not topic:
        raise HTTPException(status_code=404, detail="Topic not found")
    thread = Thread(topic_id=topic_id, user_id=current_user.id, title=thread_data.title)
    db.add(thread)
    db.commit()
    db.refresh(thread)
    return thread

@router.get("/search")
def search(q: str, db: Session = Depends(get_db), _=Depends(get_current_user)):
    like = "%" + (q or "").lower() + "%"
    topics = db.query(Topic).filter(func.lower(Topic.title).like(like)).limit(20).all()
    threads = db.query(Thread).filter(func.lower(Thread.title).like(like)).limit(50).all()
    titles = {t.id: t.title for t in db.query(Topic).all()}
    return {
        "topics": [{"id": t.id, "title": t.title} for t in topics],
        "threads": [{"id": th.id, "title": th.title, "topic_id": th.topic_id, "topic_title": titles.get(th.topic_id, "")} for th in threads]
    }
