from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from app.auth import require_admin
from app.database import SessionLocal

router = APIRouter()

def _table(db):
    row = db.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%user%'")).fetchone()
    return row[0] if row else "users"

@router.get("/users")
def list_users(current_user=Depends(require_admin)):
    db = SessionLocal()
    try:
        tbl = _table(db)
        cols = [r[1] for r in db.execute(text("PRAGMA table_info(" + tbl + ")")).fetchall()]
        name_col = "email" if "email" in cols else ("username" if "username" in cols else cols[1])
        sel = "SELECT id, " + name_col + (", role" if "role" in cols else ", 'user'") + (", is_banned" if "is_banned" in cols else ", 0") + " FROM " + tbl
        rows = db.execute(text(sel)).fetchall()
    finally:
        db.close()
    return [{"id": str(r[0]), "email": r[1], "role": r[2], "is_banned": bool(r[3])} for r in rows]

@router.post("/users/{uid}/ban")
def ban_user(uid: str, current_user=Depends(require_admin)):
    if str(current_user.id) == uid:
        raise HTTPException(status_code=400, detail="Нельзя забанить самого себя")
    db = SessionLocal()
    try:
        db.execute(text("UPDATE " + _table(db) + " SET is_banned=1 WHERE id=:id"), {"id": uid})
        db.commit()
    finally:
        db.close()
    return {"status": "ok", "message": "Пользователь забанен"}

@router.post("/users/{uid}/unban")
def unban_user(uid: str, current_user=Depends(require_admin)):
    db = SessionLocal()
    try:
        db.execute(text("UPDATE " + _table(db) + " SET is_banned=0 WHERE id=:id"), {"id": uid})
        db.commit()
    finally:
        db.close()
    return {"status": "ok", "message": "Пользователь разбанен"}
