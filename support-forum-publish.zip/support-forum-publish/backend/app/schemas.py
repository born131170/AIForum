from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime
from uuid import UUID

class UserCreate(BaseModel):
    email: EmailStr
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"

class UserResponse(BaseModel):
    id: UUID
    email: str
    role: str
    created_at: datetime
    class Config:
        from_attributes = True

class TopicCreate(BaseModel):
    title: str
    description: Optional[str] = None

class TopicResponse(BaseModel):
    id: UUID
    title: str
    description: Optional[str]
    created_at: datetime
    class Config:
        from_attributes = True

class ThreadCreate(BaseModel):
    title: str

class ThreadResponse(BaseModel):
    id: UUID
    topic_id: UUID
    user_id: UUID
    title: str
    created_at: datetime
    class Config:
        from_attributes = True

class MessageCreate(BaseModel):
    content: str

class MessageResponse(BaseModel):
    id: UUID
    thread_id: UUID
    sender_type: str
    content: str
    sources: Optional[List[dict]]
    author_email: Optional[str] = None
    created_at: datetime
    class Config:
        from_attributes = True

class AskRequest(BaseModel):
    question: str
    thread_id: Optional[UUID] = None

class AskResponse(BaseModel):
    answer: str
    sources: List[dict]

class DocumentResponse(BaseModel):
    id: UUID
    filename: str
    chunk_count: int
    created_at: datetime
    class Config:
        from_attributes = True
