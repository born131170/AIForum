import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getCurrentUser } from './api/auth';
import { useAuthStore } from './store/authStore';
import Auth from './components/Auth';
import Sidebar from './components/Sidebar';
import ChatPanel from './components/ChatPanel';
import AdminPanel from './components/AdminPanel';

export default function App() {
  const { isAuthenticated, setUser, logout } = useAuthStore();
  const [topicId, setTopicId] = useState<string | null>(null);
  const [focusThreadId, setFocusThreadId] = useState<string | null>(null);
  const [showAdmin, setShowAdmin] = useState(false);
  const [dark, setDark] = useState(() => localStorage.getItem('theme') === 'dark');

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
    localStorage.setItem('theme', dark ? 'dark' : 'light');
  }, [dark]);

  const { data: user, isLoading, error } = useQuery({
    queryKey: ['user'],
    queryFn: getCurrentUser,
    enabled: isAuthenticated,
    staleTime: 0,
    refetchOnMount: true
  });

  useEffect(() => {
    if (user) {
      console.log('✅ Загружен пользователь:', user.email, 'роль:', user.role);
      setUser(user);
    }
    if (error) {
      console.error('❌ Ошибка загрузки пользователя:', error);
    }
  }, [user, error, setUser]);

  if (!isAuthenticated) return <Auth />;

  return (
    <div className="h-screen flex flex-col">
      <header className="bg-white border-b px-6 py-3 flex items-center justify-between">
        <h1 className="text-xl font-bold">Форум техподдержки AI</h1>
        <div className="flex items-center gap-4">
          <button onClick={() => setDark(!dark)} className="px-3 py-2 bg-gray-200 rounded-md hover:bg-gray-300" title="Переключить тему">
            {dark ? '☀ Дневная' : ' Ночная'}
          </button>
          {user?.role === 'admin' && (
            <button onClick={() => setShowAdmin(!showAdmin)} className={`px-4 py-2 rounded-md ${showAdmin ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
              {showAdmin ? 'К форуму' : 'Админ-панель'}
            </button>
          )}
          <span className="text-sm text-gray-600">{user?.email}</span>
          <button onClick={logout} className="px-4 py-2 bg-red-600 text-white rounded-md">Выйти</button>
        </div>
      </header>
      <div className="flex-1 flex overflow-hidden">
        {showAdmin ? <AdminPanel /> : (
          <>
            <Sidebar
              selectedTopicId={topicId}
              onSelectTopic={(id: string) => { setTopicId(id); setFocusThreadId(null); }}
              onOpenThread={(tid: string, thid: string) => { setTopicId(tid); setFocusThreadId(thid); }}
            />
            {topicId ? <ChatPanel topicId={topicId} focusThreadId={focusThreadId} /> : <div className="flex-1 flex items-center justify-center text-gray-500">Выберите тему</div>}
          </>
        )}
      </div>
    </div>
  );
}
