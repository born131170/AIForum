import client from './client';
export interface Document { id: string; filename: string; chunk_count: number; created_at: string; }
export const uploadDocument = (file: File) => {
  const formData = new FormData();
  formData.append('file', file);
  return client.post('/admin/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } }).then(r => r.data);
};
export const getDocuments = () => client.get('/admin/documents').then(r => r.data);
export const deleteDocument = (id: string) => client.delete(`/admin/documents/${id}`);
