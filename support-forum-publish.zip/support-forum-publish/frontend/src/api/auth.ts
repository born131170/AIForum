import client from './client';
export interface User { id: string; email: string; role: string; created_at: string; }
export const register = (email: string, password: string) => client.post('/auth/register', { email, password }).then(r => r.data);
export const login = (email: string, password: string) => client.post('/auth/login', { email, password }).then(r => r.data);
export const getCurrentUser = () => client.get('/auth/me').then(r => r.data);
