import client from './client';
export interface Message { id: string; thread_id: string; sender_type: string; content: string; sources?: Array<{ file: string; snippet: string }>; created_at: string; }
export const getMessages = (threadId: string) => client.get(`/chat/threads/${threadId}/messages`).then(r => r.data);
export const postMessage = (threadId: string, content: string) => client.post(`/chat/threads/${threadId}/messages`, { content }).then(r => r.data);
export const askAI = (question: string, threadId?: string) => client.post('/ai/ask', { question, thread_id: threadId }).then(r => r.data);
