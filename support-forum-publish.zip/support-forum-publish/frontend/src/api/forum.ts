import client from './client';
export interface Topic { id: string; title: string; description?: string; created_at: string; }
export interface Thread { id: string; topic_id: string; user_id: string; title: string; created_at: string; }
export const getTopics = () => client.get('/forum/topics').then(r => r.data);
export const createTopic = (title: string, description?: string) => client.post('/forum/topics', { title, description }).then(r => r.data);
export const deleteTopic = (id: string) => client.delete(`/forum/topics/${id}`);
export const getThreads = (topicId: string) => client.get(`/forum/topics/${topicId}/threads`).then(r => r.data);
export const createThread = (topicId: string, title: string) => client.post(`/forum/topics/${topicId}/threads`, { title }).then(r => r.data);
