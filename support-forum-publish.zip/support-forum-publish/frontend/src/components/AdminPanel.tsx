import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createTopic, deleteTopic, getTopics } from '../api/forum';
import { uploadDocument, getDocuments, deleteDocument } from '../api/admin';

const H = () => ({ 'Authorization': `Bearer ${localStorage.getItem('access_token')}`, 'Content-Type': 'application/json' });

interface KeyInfo { length: number; preview: string }
interface Prov { name: string; base_url: string; hint: string; custom: boolean; models: Record<string, string>; key: KeyInfo | null }
interface State { providers: Record<string, Prov>; active_provider: string; active_model: string; embedding_model: string }
interface U { id: string; email: string; role: string; is_banned: boolean }

export default function AdminPanel() {
  const [topicTitle, setTopicTitle] = useState('');
  const [st, setSt] = useState<State | null>(null);
  const [prov, setProv] = useState('');
  const [model, setModel] = useState('');
  const [models, setModels] = useState<Record<string, string>>({});
  const [modelSrc, setModelSrc] = useState('');
  const [keyInput, setKeyInput] = useState('');
  const [msg, setMsg] = useState('');
  const [showAI, setShowAI] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [add, setAdd] = useState({ id: '', name: '', base_url: '', api_key: '', models: '' });
  const [users, setUsers] = useState<U[]>([]);
  const [usersMsg, setUsersMsg] = useState('');
  const [emb, setEmb] = useState<{ kind: string; model: string; provider: string }>({ kind: 'local', model: 'auto', provider: '' });
  const [embOpts, setEmbOpts] = useState<any>(null);
  const [embMsg, setEmbMsg] = useState('');
  const [promptText, setPromptText] = useState('');
  const [promptMsg, setPromptMsg] = useState('');
  const queryClient = useQueryClient();

  const { data: topics } = useQuery({ queryKey: ['topics'], queryFn: getTopics });
  const { data: documents } = useQuery({ queryKey: ['documents'], queryFn: getDocuments });

  const createTopicMutation = useMutation({
    mutationFn: () => createTopic(topicTitle, ''),
    onSuccess: () => { setTopicTitle(''); queryClient.invalidateQueries({ queryKey: ['topics'] }); },
  });
  const deleteTopicMutation = useMutation({
    mutationFn: deleteTopic,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['topics'] }),
  });
  const uploadDocMutation = useMutation({
    mutationFn: uploadDocument,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['documents'] }),
  });
  const deleteDocMutation = useMutation({
    mutationFn: deleteDocument,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['documents'] }),
  });

  const fetchModels = async (pid: string) => {
    try {
      const r = await fetch('/api/ai-settings/models?provider=' + pid, { headers: H() });
      const d = await r.json();
      setModelSrc(d.source === 'live' ? 'список получен от провайдера' : 'базовый список (провайдер не дал список)');
      return { ...(d.models || {}) };
    } catch {
      setModelSrc('базовый список');
      return {};
    }
  };

  const loadState = async () => {
    const r = await fetch('/api/ai-settings/state', { headers: H() });
    const d: State = await r.json();
    setSt(d);
    const pid = d.active_provider;
    setProv(pid);
    let ms = await fetchModels(pid);
    if (Object.keys(ms).length === 0) ms = { ...(d.providers[pid]?.models || {}) };
    if (d.active_model && !ms[d.active_model]) ms = { ...ms, [d.active_model]: d.active_model };
    setModels(ms);
    setModel(d.active_model || Object.keys(ms)[0] || '');
    setPromptText(d.prompt || '');
  };

  const loadUsers = async () => {
    const r = await fetch('/api/admin/users', { headers: H() });
    if (r.ok) setUsers(await r.json());
  };

  useEffect(() => { loadState(); loadUsers(); loadEmb(); }, []);

  const refreshModels = async (pid: string) => {
    const ms = await fetchModels(pid);
    if (Object.keys(ms).length === 0) return;
    if (model && !ms[model]) ms[model] = model;
    setModels(ms);
  };

  const onProvChange = async (pid: string) => {
    setProv(pid);
    setKeyInput('');
    const ms = await fetchModels(pid);
    setModels(ms);
    setModel(Object.keys(ms)[0] || '');
  };

  const apply = async () => {
    setMsg('Сохранение...');
    if (keyInput.trim()) {
      await fetch('/api/ai-settings/key', { method: 'POST', headers: H(), body: JSON.stringify({ provider: prov, api_key: keyInput.trim() }) });
    }
    const r = await fetch('/api/ai-settings/active', { method: 'POST', headers: H(), body: JSON.stringify({ provider: prov, model }) });
    const d = await r.json();
    setMsg(d.message || 'Сохранено');
    setKeyInput('');
    await loadState();
  };

  const addProvider = async () => {
    const ms: Record<string, string> = {};
    add.models.split(',').map(s => s.trim()).filter(Boolean).forEach(m => { ms[m] = m; });
    await fetch('/api/ai-settings/provider', { method: 'POST', headers: H(), body: JSON.stringify(add) });
    setShowAdd(false);
    setAdd({ id: '', name: '', base_url: '', api_key: '', models: '' });
    loadState();
  };

  const delProvider = async (pid: string) => {
    if (!window.confirm('Удалить провайдер?')) return;
    const r = await fetch('/api/ai-settings/provider/' + pid, { method: 'DELETE', headers: H() });
    const d = await r.json();
    setMsg(d.message || 'Удалено');
    loadState();
  };

  const toggleBan = async (u: U) => {
    const r = await fetch('/api/admin/users/' + u.id + (u.is_banned ? '/unban' : '/ban'), { method: 'POST', headers: H() });
    const d = await r.json();
    setUsersMsg(d.message || d.detail || '');
    loadUsers();
  };

  const savePrompt = async () => {
    const r = await fetch('/api/ai-settings/prompt', { method: 'POST', headers: H(), body: JSON.stringify({ prompt: promptText }) });
    const d = await r.json();
    setPromptMsg(d.message || 'Сохранено');
  };

  const loadEmb = async () => {
    try {
      const r = await fetch('/api/ai-settings/embedding', { headers: H() });
      if (r.ok) { const d = await r.json(); setEmbOpts(d); setEmb(d.current); }
    } catch { }
  };

  const applyEmb = async () => {
    const r = await fetch('/api/ai-settings/embedding', { method: 'POST', headers: H(), body: JSON.stringify(emb) });
    const d = await r.json();
    setEmbMsg(d.message || 'Сохранено');
  };

  const cur = st?.providers[prov];

  return (
    <div className="flex-1 p-6 overflow-y-auto">
      <h1 className="text-2xl font-bold mb-6">Панель администратора</h1>

      <section className="mb-8 bg-blue-50 p-4 rounded-lg border border-blue-200">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold">◆ Настройки AI: провайдер, модель, ключ</h2>
          <button onClick={() => setShowAI(!showAI)} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            {showAI ? 'Скрыть' : 'Показать'}
          </button>
        </div>

        {showAI && st && (
          <div className="space-y-3">
            <div className="flex gap-2 items-center">
              <label className="text-sm font-medium w-40">Провайдер:</label>
              <select value={prov} onChange={e => onProvChange(e.target.value)} className="flex-1 px-3 py-2 border border-gray-300 rounded-md">
                {Object.entries(st.providers).map(([id, p]) => (
                  <option key={id} value={id}>{p.name}{id === st.active_provider ? ' (активен)' : ''}</option>
                ))}
              </select>
              <button onClick={() => { setAdd({ id: prov, name: cur?.name || '', base_url: cur?.base_url || '', api_key: '', models: Object.keys(cur?.models || {}).join(', ') }); setShowAdd(true); }}
                className="px-3 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600" title="Редактировать провайдера (в т.ч. свой URL)">✎</button>
              <button onClick={() => delProvider(prov)} disabled={prov === st.active_provider}
                className="px-3 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 disabled:opacity-40" title="Удалить провайдер">✕</button>
            </div>

            <div className="flex gap-2 items-center">
              <label className="text-sm font-medium w-40">Модель:</label>
              <select value={model} onChange={e => setModel(e.target.value)} className="flex-1 px-3 py-2 border border-gray-300 rounded-md">
                {Object.entries(models).map(([id, label]) => (
                  <option key={id} value={id}>{label}</option>
                ))}
              </select>
              <button onClick={() => refreshModels(prov)} className="px-3 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700" title="Обновить список моделей с API провайдера">⟳</button>
            </div>
            {modelSrc && <div className="text-xs text-gray-500 ml-40">{modelSrc}</div>}

            <div className="ml-40 text-sm text-gray-700">
              {cur?.key
                ? <>Сохранённый ключ: <b>{cur.key.length} символов</b> ({cur.key.preview})</>
                : <span className="text-red-600">Ключ для этого провайдера не сохранён</span>}
              {cur?.hint && <span className="text-gray-500"> · {cur.hint}</span>}
            </div>

            <div className="flex gap-2 items-center">
              <label className="text-sm font-medium w-40">API-ключ ({prov}):</label>
              <input type="password" value={keyInput} onChange={e => setKeyInput(e.target.value)}
                placeholder="Вставьте ключ именно этого провайдера" className="flex-1 px-3 py-2 border border-gray-300 rounded-md" />
            </div>

            <div className="flex gap-2">
              <button onClick={apply} className="flex-1 bg-green-600 text-white py-2 rounded-md hover:bg-green-700">Сохранить и применить</button>
              <button onClick={() => setShowAdd(!showAdd)} className="px-4 py-2 bg-gray-700 text-white rounded-md hover:bg-gray-800">+ Провайдер</button>
            </div>
            {msg && <div className="text-sm text-green-700">{msg}</div>}

            {showAdd && (
              <div className="bg-white p-3 rounded border space-y-2">
                <div className="font-medium">Добавить ИЛИ редактировать провайдера (OpenAI-совместимый)</div>
                <input placeholder="id (латиницей, например together)" value={add.id} onChange={e => setAdd({ ...add, id: e.target.value })} className="w-full px-3 py-2 border rounded-md" />
                <input placeholder="Название" value={add.name} onChange={e => setAdd({ ...add, name: e.target.value })} className="w-full px-3 py-2 border rounded-md" />
                <input placeholder="Base URL, например https://api.together.xyz/v1" value={add.base_url} onChange={e => setAdd({ ...add, base_url: e.target.value })} className="w-full px-3 py-2 border rounded-md" />
                <input placeholder="API-ключ (пусто = сохранить текущий)" value={add.api_key} onChange={e => setAdd({ ...add, api_key: e.target.value })} className="w-full px-3 py-2 border rounded-md" />
                <input placeholder="Модели через запятую (или пусто — подтянутся с API)" value={add.models} onChange={e => setAdd({ ...add, models: e.target.value })} className="w-full px-3 py-2 border rounded-md" />
                <button onClick={addProvider} className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">Добавить</button>
              </div>
            )}
          </div>
        )}
      </section>

      <section className="mb-8 bg-teal-50 p-4 rounded-lg border border-teal-200">
        <h2 className="text-xl font-semibold mb-3"> Эмбеддинг-модель (поиск по документации)</h2>
        <p className="text-sm text-gray-600 mb-2">Локально — офлайн на этом ПК; GigaChat — лучшее качество для русского (API Сбера); OpenAI — через провайдера (ProxyAPI и др.). После «Применить» перезапустите uvicorn — база переиндексируется сама.</p>
        {embOpts && (
          <div className="space-y-2">
            <div className="flex gap-2 items-center">
              <label className="text-sm font-medium w-44">Тип эмбеддинга:</label>
              <select value={emb.kind} onChange={e => { const k = e.target.value; setEmb({ ...emb, kind: k, provider: k === 'openai' ? (emb.provider || (embOpts.providers[0] && embOpts.providers[0].id) || '') : emb.provider, model: k === 'local' ? embOpts.local_models[0] : k === 'gigachat' ? embOpts.gigachat_models[0] : (embOpts.openai_models[2] || embOpts.openai_models[0]) }); }} className="flex-1 px-3 py-2 border border-gray-300 rounded-md">
                <option value="local">Локально (fastembed, офлайн)</option>
                <option value="gigachat">GigaChat Embeddings (API Сбера)</option>
                <option value="openai">OpenAI Embeddings (через провайдера)</option>
              </select>
            </div>
            {emb.kind === 'openai' && (
              <div className="flex gap-2 items-center">
                <label className="text-sm font-medium w-44">Провайдер (ключ/адрес):</label>
                <select value={emb.provider} onChange={e => setEmb({ ...emb, provider: e.target.value })} className="flex-1 px-3 py-2 border border-gray-300 rounded-md">
                  {embOpts.providers.map((p: any) => (<option key={p.id} value={p.id}>{p.name}</option>))}
                </select>
              </div>
            )}
            <div className="flex gap-2 items-center">
              <label className="text-sm font-medium w-44">Модель:</label>
              {emb.kind === 'openai' ? (
                <input value={emb.model} onChange={e => setEmb({ ...emb, model: e.target.value })} className="flex-1 px-3 py-2 border border-gray-300 rounded-md" />
              ) : (
                <select value={emb.model} onChange={e => setEmb({ ...emb, model: e.target.value })} className="flex-1 px-3 py-2 border border-gray-300 rounded-md">
                  {(emb.kind === 'local' ? embOpts.local_models : embOpts.gigachat_models).map((m: string) => (<option key={m} value={m}>{m}</option>))}
                </select>
              )}
            </div>
            <button onClick={applyEmb} className="px-4 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700">Применить эмбеддинг</button>
            {embMsg && <div className="text-sm text-green-700 mt-1">{embMsg}</div>}
          </div>
        )}
      </section>

      <section className="mb-8 bg-red-50 p-4 rounded-lg border border-red-200">
        <h2 className="text-xl font-semibold mb-3"> Пользователи: роли и бан</h2>
        {usersMsg && <div className="text-sm text-gray-700 mb-2">{usersMsg}</div>}
        <div className="bg-white rounded shadow overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left border-b bg-gray-50">
                <th className="py-2 px-3">Email</th>
                <th className="py-2 px-3">Роль</th>
                <th className="py-2 px-3">Статус</th>
                <th className="py-2 px-3 text-right">Действие</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id} className="border-b last:border-0">
                  <td className="py-2 px-3">{u.email}</td>
                  <td className="py-2 px-3">{u.role === 'admin' ? '👑 админ' : '● пользователь'}</td>
                  <td className="py-2 px-3">
                    {u.is_banned
                      ? <span className="px-2 py-0.5 rounded bg-red-100 text-red-700 font-medium">ЗАБАНЕН</span>
                      : <span className="px-2 py-0.5 rounded bg-green-100 text-green-700 font-medium">активен</span>}
                  </td>
                  <td className="py-2 px-3 text-right">
                    <button onClick={() => toggleBan(u)}
                      className={u.is_banned
                        ? 'px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 text-sm'
                        : 'px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 text-sm'}>
                      {u.is_banned ? 'Разбанить' : 'Забанить'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-3">▤ Промпт модели</h2>
        <p className="text-sm text-gray-600 mb-2">Системный промпт для AI. Обязательны плейсхолдеры {'{context}'} и {'{question}'} — иначе будет использован стандартный промпт. Пустое поле = стандартный.</p>
        <textarea value={promptText} onChange={e => setPromptText(e.target.value)} rows={6} className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm" placeholder="Ты ассистент техподдержки... {'{context}'} ... {'{question}'} ..." />
        <div className="flex gap-2 mt-2">
          <button onClick={savePrompt} className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700">Сохранить промпт</button>
          <button onClick={() => { setPromptText(''); savePrompt(); }} className="px-4 py-2 bg-gray-300 rounded-md hover:bg-gray-400">Сбросить</button>
        </div>
        {promptMsg && <div className="text-sm text-green-700 mt-2">{promptMsg}</div>}
      </section>

      <section className="mb-8 bg-white p-4 rounded-lg border border-gray-200">
        <h2 className="text-xl font-semibold mb-4">Управление темами</h2>
        <div className="bg-white rounded-lg shadow p-4 mb-4">
          <input value={topicTitle} onChange={e => setTopicTitle(e.target.value)} placeholder="Название темы" className="w-full px-3 py-2 border rounded-md mb-2" />
          <button onClick={() => createTopicMutation.mutate()} disabled={!topicTitle.trim()} className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50">Создать тему</button>
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <ul className="space-y-2">
            {topics?.map((t: any) => (
              <li key={t.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <div className="font-medium">{t.title}</div>
                <button onClick={() => { if (window.confirm('Удалить тему?')) deleteTopicMutation.mutate(t.id); }} className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 text-sm">Удалить</button>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-4">Документация (RAG)</h2>
        <div className="bg-white rounded-lg shadow p-4 mb-4">
          <input type="file" accept=".pdf,.txt,.docx,.md" className="w-full"
            onChange={e => { const f = e.target.files?.[0]; if (f) uploadDocMutation.mutate(f); e.target.value = ''; }} />
          {uploadDocMutation.isPending && <div className="text-sm text-gray-600 mt-2">Обработка...</div>}
        </div>
        <div className="bg-white rounded-lg shadow p-4">
          <ul className="space-y-2">
            {documents?.map((d: any) => (
              <li key={d.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <div>
                  <div className="font-medium">{d.filename}</div>
                  <div className="text-sm text-gray-600">{d.chunk_count} фрагментов</div>
                </div>
                <button onClick={() => { if (window.confirm('Удалить документ?')) deleteDocMutation.mutate(d.id); }} className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700 text-sm">Удалить</button>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}
