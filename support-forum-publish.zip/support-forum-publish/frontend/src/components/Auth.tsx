import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { register, login } from '../api/auth';
import { useAuthStore } from '../store/authStore';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { setUser } = useAuthStore();

  const loginMut = useMutation({
    mutationFn: () => login(email, password),
    onSuccess: (d: any) => {
      localStorage.setItem('access_token', d.access_token);
      setTimeout(() => window.location.reload(), 100);
    },
    onError: (e: any) => setError(e.response?.data?.detail || 'Ошибка')
  });

  const regMut = useMutation({
    mutationFn: () => register(email, password),
    onSuccess: () => loginMut.mutate(),
    onError: (e: any) => setError(e.response?.data?.detail || 'Ошибка')
  });

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <h2 className="text-2xl font-bold text-center mb-6">{isLogin ? 'Вход' : 'Регистрация'}</h2>
        <form onSubmit={(e) => { e.preventDefault(); setError(''); isLogin ? loginMut.mutate() : regMut.mutate(); }} className="space-y-4">
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" className="w-full px-3 py-2 border rounded-md" required />
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Пароль" className="w-full px-3 py-2 border rounded-md" required />
          {error && <div className="text-red-600 text-sm">{error}</div>}
          <button type="submit" disabled={loginMut.isPending || regMut.isPending} className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 disabled:opacity-50">
            {isLogin ? 'Войти' : 'Зарегистрироваться'}
          </button>
        </form>
        <button onClick={() => setIsLogin(!isLogin)} className="mt-4 w-full text-blue-600 hover:underline text-sm">
          {isLogin ? 'Нет аккаунта? Зарегистрироваться' : 'Уже есть аккаунт? Войти'}
        </button>
      </div>
    </div>
  );
}
