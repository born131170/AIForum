import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getMessages, postMessage, askAI } from '../api/chat';
import { getThreads, createThread } from '../api/forum';

export default function ChatPanel({ topicId, focusThreadId }: { topicId: string; focusThreadId?: string | null }) {
  const [threadId, setThreadId] = useState<string | null>(null);
  const [msg, setMsg] = useState('');
  const [newThreadTitle, setNewThreadTitle] = useState('');
  const [showNew, setShowNew] = useState(false);
  const [myEmail, setMyEmail] = useState('');
  const endRef = useRef<HTMLDivElement>(null);
  const qc = useQueryClient();

  const { data: threads } = useQuery({ queryKey: ['threads', topicId], queryFn: () => getThreads(topicId) });
  const { data: messages } = useQuery({ queryKey: ['messages', threadId], queryFn: () => getMessages(threadId!), enabled: !!threadId });

  const createThreadMut = useMutation({ mutationFn: (t: string) => createThread(topicId, t), onSuccess: (d: any) => { setThreadId(d.id); setShowNew(false); setNewThreadTitle(''); qc.invalidateQueries({ queryKey: ['threads', topicId] }); } });
  const postMsgMut = useMutation({ mutationFn: (c: string) => postMessage(threadId!, c), onSuccess: () => qc.invalidateQueries({ queryKey: ['messages', threadId] }) });
  const askAIMut = useMutation({ mutationFn: (q: string) => askAI(q, threadId!), onSuccess: () => qc.invalidateQueries({ queryKey: ['messages', threadId] }) });

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  useEffect(() => { if (focusThreadId) setThreadId(focusThreadId); }, [focusThreadId, topicId]);

  useEffect(() => {
    fetch('/api/auth/me', { headers: { Authorization: `Bearer ${localStorage.getItem('access_token')}` } })
      .then(r => (r.ok ? r.json() : null))
      .then(d => { if (d && d.email) setMyEmail(d.email); })
      .catch(() => {});
  }, []);

  const label = (m: any) => {
    if (m.sender_type === 'ai') return 'AI';
    if (m.sender_type === 'support') return 'Поддержка';
    if (m.author_email) return m.author_email === myEmail ? 'Вы' : m.author_email;
    return 'Пользователь';
  };

  if (!threadId) {
    return (
      <div className="flex-1 flex flex-col">
        <div className="p-4 border-b border-gray-200"><h2 className="text-lg font-semibold">Треды</h2></div>
        <div className="flex-1 overflow-y-auto p-4">
          {threads?.map((t: any) => (
            <div key={t.id} onClick={() => setThreadId(t.id)} className="p-3 mb-2 bg-white rounded-lg shadow cursor-pointer hover:shadow-md">
              <div className="font-medium">{t.title}</div>
              <div className="text-sm text-gray-500">{new Date(t.created_at).toLocaleString('ru-RU')}</div>
            </div>
          ))}
          <button onClick={() => setShowNew(true)} className="w-full p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 mt-4">+ Новый тред</button>
          {showNew && (
            <div className="mt-4 p-4 bg-gray-50 rounded-lg">
              <input value={newThreadTitle} onChange={e => setNewThreadTitle(e.target.value)} placeholder="Название" className="w-full px-3 py-2 border rounded-md mb-2" />
              <div className="flex gap-2">
                <button onClick={() => createThreadMut.mutate(newThreadTitle)} className="flex-1 bg-blue-600 text-white py-2 rounded-md">Создать</button>
                <button onClick={() => setShowNew(false)} className="flex-1 bg-gray-300 py-2 rounded-md">Отмена</button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <button onClick={() => setThreadId(null)} className="text-blue-600 hover:underline">&larr; Назад</button>
        <h2 className="font-semibold">{threads?.find((t: any) => t.id === threadId)?.title}</h2>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages?.map((m: any) => (
          <div key={m.id} className={`max-w-[80%] p-3 rounded-lg ${m.sender_type === 'user' ? 'ml-auto bg-blue-100' : m.sender_type === 'ai' ? 'bg-green-100' : 'bg-gray-100'}`}>
            <div className="text-xs text-gray-600 mb-1 font-medium">{label(m)}</div>
            <div className="whitespace-pre-wrap">{m.content}</div>
            {m.sender_type === 'ai' && m.sources?.length > 0 && (
              <details className="mt-2 text-xs">
                <summary className="cursor-pointer text-gray-600">Источники ({m.sources.length})</summary>
                <ul className="mt-1 space-y-1">{m.sources.map((s: any, i: number) => <li key={i}><b>{s.file}</b>: {s.snippet.slice(0, 150)}...</li>)}</ul>
              </details>
            )}
          </div>
        ))}
        <div ref={endRef} />
      </div>
      <div className="border-t p-4 flex gap-2">
        <input value={msg} onChange={e => setMsg(e.target.value)} placeholder="Введите сообщение..." className="flex-1 px-3 py-2 border rounded-md" onKeyDown={e => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), postMsgMut.mutate(msg), setMsg(''))} />
        <button onClick={() => { postMsgMut.mutate(msg); setMsg(''); }} disabled={!msg.trim()} className="px-4 py-2 bg-blue-600 text-white rounded-md disabled:opacity-50">В чат</button>
        <button onClick={() => { askAIMut.mutate(msg); setMsg(''); }} disabled={!msg.trim() || askAIMut.isPending} className="px-4 py-2 bg-green-600 text-white rounded-md disabled:opacity-50">{askAIMut.isPending ? 'Думаю...' : 'Спросить AI'}</button>
      </div>
    </div>
  );
}
