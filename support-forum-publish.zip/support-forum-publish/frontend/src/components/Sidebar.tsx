import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getTopics } from '../api/forum';

const H = () => ({ Authorization: `Bearer ${localStorage.getItem('access_token')}` });

export default function Sidebar({ selectedTopicId, onSelectTopic, onOpenThread }: { selectedTopicId: string | null; onSelectTopic: (id: string) => void; onOpenThread: (topicId: string, threadId: string) => void }) {
  const [q, setQ] = useState('');
  const [res, setRes] = useState<{ topics: any[]; threads: any[] } | null>(null);
  const { data: topics, isLoading } = useQuery({ queryKey: ['topics'], queryFn: getTopics });

  const doSearch = async (query: string) => {
    if (query.trim().length < 2) { setRes(null); return; }
    try {
      const r = await fetch('/api/forum/search?q=' + encodeURIComponent(query), { headers: H() });
      if (r.ok) setRes(await r.json());
    } catch { }
  };

  return (
    <div className="w-72 bg-gray-100 border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-semibold mb-2">Темы форума</h2>
        <input value={q} onChange={e => { setQ(e.target.value); doSearch(e.target.value); }} placeholder="⌕ Поиск по темам и тредам..." className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm" />
      </div>
      <div className="flex-1 overflow-y-auto">
        {res ? (
          <div className="p-2">
            {res.topics.length > 0 && <div className="px-2 py-1 text-xs font-semibold text-gray-500 uppercase">Темы</div>}
            {res.topics.map((t: any) => (
              <div key={t.id} onClick={() => { onSelectTopic(t.id); setQ(''); setRes(null); }} className="p-3 mb-1 bg-white rounded shadow-sm cursor-pointer hover:shadow">▸ {t.title}</div>
            ))}
            {res.threads.length > 0 && <div className="px-2 py-1 text-xs font-semibold text-gray-500 uppercase">Треды</div>}
            {res.threads.map((th: any) => (
              <div key={th.id} onClick={() => { onOpenThread(th.topic_id, th.id); setQ(''); setRes(null); }} className="p-3 mb-1 bg-white rounded shadow-sm cursor-pointer hover:shadow">
                ▪ {th.title}
                <div className="text-xs text-gray-500 mt-0.5">в теме: {th.topic_title}</div>
              </div>
            ))}
            {res.topics.length === 0 && res.threads.length === 0 && <div className="p-4 text-sm text-gray-500">Ничего не найдено</div>}
          </div>
        ) : isLoading ? <div className="p-4 text-gray-500">Загрузка...</div> : (
          <ul className="divide-y divide-gray-200">
            {topics?.map((t: any) => (
              <li key={t.id} onClick={() => onSelectTopic(t.id)} className={`p-4 cursor-pointer hover:bg-gray-200 ${selectedTopicId === t.id ? 'bg-blue-50 border-l-4 border-blue-600' : ''}`}>
                <div className="font-medium">{t.title}</div>
                {t.description && <div className="text-sm text-gray-600 mt-1">{t.description}</div>}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
