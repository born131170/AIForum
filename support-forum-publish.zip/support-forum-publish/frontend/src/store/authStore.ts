import { create } from 'zustand';
import { User } from '../api/auth';
interface AuthState { user: User | null; isAuthenticated: boolean; setUser: (u: User | null) => void; logout: () => void; }
export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: !!localStorage.getItem('access_token'),
  setUser: (u) => set({ user: u, isAuthenticated: !!u }),
  logout: () => { localStorage.removeItem('access_token'); set({ user: null, isAuthenticated: false }); }
}));
