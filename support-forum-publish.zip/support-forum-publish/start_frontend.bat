@echo off
cd /d "%~dp0frontend"
where npm >nul 2>&1
if errorlevel 1 (
  for %%p in ("%~dp0nodejs" "%USERPROFILE%\nodejs" "C:\Program Files\nodejs" "D:\nodejs") do if exist %%p set "PATH=%PATH%;%%p"
)
:loop
call npm run dev -- --host
echo.
echo Frontend stopped. Auto-restart in 2 sec... To stop entirely, close the window.
timeout /t 2 >nul
goto loop
